package com.example.flexstend.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.TextAppearanceSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.flexstend.R;

import java.util.ArrayList;

public class PainelFragment extends Fragment {

    private ArrayAdapter<CharSequence> numbersAdapter;
    private ArrayList<Double> salariosList;
    private ArrayList<Double> gastosList;

    private TextView textResta;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_painell, container, false);

        salariosList = new ArrayList<>();
        gastosList = new ArrayList<>();
        numbersAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1);

        final ListView listView = view.findViewById(R.id.listView);
        listView.setAdapter(numbersAdapter);

        textResta = view.findViewById(R.id.textResta);

        Button btnSalario = view.findViewById(R.id.btnSalario);
        btnSalario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInputDialog("Renda R$: ", salariosList);
            }
        });

        Button btnGasto = view.findViewById(R.id.btnGasto);
        btnGasto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInputDialog("Gasto R$: ", gastosList);
            }
        });

        Button btnCalcular = view.findViewById(R.id.btnCalcular);
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularDiferenca();
            }
        });

        return view;
    }

    private void showInputDialog(final String prefixo, final ArrayList<Double> lista) {
        AlertDialog.Builder construtor = new AlertDialog.Builder(getActivity());
        construtor.setTitle("Adicionar Valor");

        // Crie um layout para o diálogo
        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);

        // Crie um EditText para o nome
        final EditText entradaNome = new EditText(getActivity());
        entradaNome.setHint("Nome");
        layout.addView(entradaNome);

        // Crie um EditText para o valor
        final EditText entradaValor = new EditText(getActivity());
        entradaValor.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        entradaValor.setHint("Valor");
        layout.addView(entradaValor);

        construtor.setView(layout);

        construtor.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String nome = entradaNome.getText().toString();
                String valorStr = entradaValor.getText().toString();

                if (!nome.isEmpty() && !valorStr.isEmpty()) {
                    double valor = Double.parseDouble(valorStr);

                    lista.add(valor);

                    String item = nome + ": " + prefixo + valorStr;
                    SpannableString spannableString = new SpannableString(item);

                    if (prefixo.equals("Renda R$: ")) {
                        spannableString.setSpan(new TextAppearanceSpan(requireContext(), R.style.GreenText), 0, item.length(), 0);
                    } else if (prefixo.equals("Gasto R$: ")) {
                        spannableString.setSpan(new TextAppearanceSpan(requireContext(), R.style.RedText), 0, item.length(), 0);
                    }

                    numbersAdapter.add(spannableString);
                    numbersAdapter.notifyDataSetChanged();
                }
            }
        });

        construtor.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        construtor.show();
    }

    private void calcularDiferenca() {
        double somaSalarios = 0;
        double somaGastos = 0;

        for (Double salario : salariosList) {
            somaSalarios += salario;
        }

        for (Double gasto : gastosList) {
            somaGastos += gasto;
        }

        double diferenca = somaSalarios - somaGastos;
        textResta.setText("Resta: R$: " + diferenca);


        for (int i = 0; i < numbersAdapter.getCount(); i++) {
            CharSequence item = numbersAdapter.getItem(i);
            numbersAdapter.remove(item);
            numbersAdapter.add(item);
        }

        for (Double salario : salariosList) {
            String item ="R$: " + salario ;
        }

        for (Double gasto : gastosList) {
            String item = "R$: " + gasto ;
        }

        numbersAdapter.notifyDataSetChanged();

        double ruim = (0.2 * somaSalarios);
        double bom = (0.4 * somaSalarios);

        if(diferenca > 0 && diferenca < ruim){
            textResta.setText("Voce tem muitas dividas, restam menos que 20%, Resta: "+ diferenca);
        } else if (diferenca >= ruim && diferenca < bom ) {
            textResta.setText("Situação Boa, restou:20% - 40%, Resta: " + diferenca);
        } else if (diferenca < 0) {
            textResta.setText("Voce esta devendo mais do que recebe, deve: " + diferenca);
        }else if (diferenca == 0){
            textResta.setText("Voce pagou as dividas mas não sobrou nada " + diferenca);
        }else{
            textResta.setText("Sobrou mais de 40% nesse periodo, Restou: " + diferenca);
        }

    }
}